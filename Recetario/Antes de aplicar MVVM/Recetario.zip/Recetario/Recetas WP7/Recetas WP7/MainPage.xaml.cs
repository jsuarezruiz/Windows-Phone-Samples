﻿using Microsoft.Phone.Controls;
using Recetas_WP7.Common;
using Recetas_WP7.Data;
using System;
using System.Windows.Controls;

namespace Recetas_WP7
{
    public partial class MainPage : PhoneApplicationPage
    {
        private Microsoft.Phone.Shell.ProgressIndicator pi;

        // Constructor
        public MainPage()
        {
            InitializeComponent(); 
            //TiltEffect.SetIsTiltEnabled(App.Current.RootVisual, true);
        }

        protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
        {
            if (!App.Recipes.IsLoaded)
            {
                pi = new Microsoft.Phone.Shell.ProgressIndicator();
                pi.IsIndeterminate = true;
                pi.Text = "Cargando, espere por favor ...";
                pi.IsVisible = true;

                Microsoft.Phone.Shell.SystemTray.SetIsVisible(this, true);
                Microsoft.Phone.Shell.SystemTray.SetProgressIndicator(this, pi);

                App.Recipes.LoadLocalDataAsync();

                lstGroups.DataContext = App.Recipes.ItemGroups;

                pi.IsVisible = false;
                Microsoft.Phone.Shell.SystemTray.SetIsVisible(this, false);
            }
            base.OnNavigatedTo(e);
        }

        private void lstGroups_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lstGroups.SelectedIndex > -1)
                NavigationService.Navigate(new Uri("/GroupDetailPage.xaml?ID=" + (lstGroups.SelectedItem as RecipeDataGroup).UniqueId, UriKind.Relative));
        }
    }
}