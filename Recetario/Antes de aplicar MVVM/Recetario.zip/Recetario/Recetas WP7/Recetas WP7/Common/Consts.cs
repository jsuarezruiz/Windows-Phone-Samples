﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Recetas_WP7.Common
{
    public class Consts
    {
        public const string UserImagesDirectory = "Recetas-Images";
        public const string UserImagesFile = "UserImages.txt";
        public static readonly string[] TrialGroups = { "Chinese" };
    }
}
