﻿using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Microsoft.Phone.Tasks;
using Recetas_WP7.Common;
using Recetas_WP7.Data;
using System;
using System.IO.IsolatedStorage;
using System.Windows;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;

namespace Recetas_WP7
{
    public partial class RecipeDetailPage : PhoneApplicationPage
    {
        private RecipeDataItem item;
        private const string removeAlarmUri = "/Assets/Icons/alarmRemove.png";
        private const string AlarmUri = "/Assets/Icons/alarm.png";

        private const string removeFavUri = "/Assets/Icons/unlike.png";
        private const string FavUri = "/Assets/Icons/like.png";

        public RecipeDetailPage()
        {
            InitializeComponent();
        }

        public ApplicationBarIconButton alarmBtn
        {
            get
            {
                var appBar = (ApplicationBar)ApplicationBar;
                var count = appBar.Buttons.Count;
                for (var i = 0; i < count; i++)
                {
                    ApplicationBarIconButton btn = appBar.Buttons[i] as ApplicationBarIconButton;
                    if (btn.IconUri.OriginalString.Contains("alarm"))
                        return btn;
                }
                return null;
            }
        }

        public ApplicationBarIconButton pinBtn
        {
            get
            {
                var appBar = (ApplicationBar)ApplicationBar;
                var count = appBar.Buttons.Count;
                for (var i = 0; i < count; i++)
                {
                    ApplicationBarIconButton btn = appBar.Buttons[i] as ApplicationBarIconButton;
                    if (btn.IconUri.OriginalString.Contains("like"))
                        return btn;
                }
                return null;
            }
        }

        void SetPinBar()
        {
            var uri = NavigationService.Source.ToString();
            if (Features.Tile.TileExists(uri))
            {
                pinBtn.IconUri = new Uri(removeFavUri, UriKind.Relative);
                pinBtn.Text = "Unpin";
            }
            else
            {
                pinBtn.IconUri = new Uri(FavUri, UriKind.Relative);
                pinBtn.Text = "Pin";
            }
        }

        void SetScheduleBar(string name)
        {
            var isScheduled = Features.Notifications.IsScheduled(name);
            if (isScheduled)
            {
                alarmBtn.IconUri = new Uri(removeAlarmUri, UriKind.Relative);
                alarmBtn.Text = "Eliminar Alarma";
            }
            else
            {
                alarmBtn.IconUri = new Uri(AlarmUri, UriKind.Relative);
                alarmBtn.Text = "Crear Alarma";
            }
        }

        void btnPinToStart_Click(object sender, EventArgs e)
        {
            var uri = NavigationService.Source.ToString();
            if (Features.Tile.TileExists(uri))
                Features.Tile.DeleteTile(uri);
            else
                Features.Tile.SetTile(item, uri);

            SetPinBar();
        }

        void btnStartCooking_Click(object sender, EventArgs e)
        {
            Features.Notifications.SetReminder(item);
            SetScheduleBar(item.UniqueId);
        }

        protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
        {
            string UniqueId = string.Empty;
            UniqueId = NavigationContext.QueryString["ID"];

            if (!App.Recipes.IsLoaded)
                App.Recipes.LoadLocalDataAsync();

            NavigateToRecipe(UniqueId);

            base.OnNavigatedTo(e);
        }

        private void NavigateToRecipe(string UniqueId)
        {
            item = App.Recipes.FindRecipe(UniqueId);
            pivot.DataContext = item;

            SetScheduleBar(item.UniqueId);
            SetPinBar();
        }
    }
}