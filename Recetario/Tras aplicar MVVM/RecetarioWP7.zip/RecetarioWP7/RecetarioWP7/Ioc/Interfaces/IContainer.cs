﻿
namespace RecetarioWP7.Ioc
{
    public interface IContainer
    {
        T Resolve<T>();
    }
}
