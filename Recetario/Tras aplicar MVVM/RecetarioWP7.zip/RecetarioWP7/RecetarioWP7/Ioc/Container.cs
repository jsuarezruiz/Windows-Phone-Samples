﻿using Microsoft.Practices.Unity;
using RecetarioWP7.Services;
using RecetarioWP7.Services.Interfaces;
using RecetarioWP7.ViewModel;
using RecetarioWP7.ViewModel.Interfaces;

namespace RecetarioWP7.Ioc
{
    //
    // Unity 2.1
    // http://msdn.microsoft.com/en-us/library/hh237493.aspx
    //
    // patterns & practices - Unity
    // http://unity.codeplex.com/
    //
    public class Container : IContainer
    {
        private IUnityContainer _currentContainer;

        public Container()
        {
            // Crea el contenedor de inyección de dependencias
            this._currentContainer = new UnityContainer();

            // Añade los Services de los que dependen los ViewModel
            this._currentContainer.RegisterType<ILiveTileService, LiveTileService>();
            this._currentContainer.RegisterType<IStorageService, StorageService>();
            this._currentContainer.RegisterType<IDialogService, DialogService>();
            this._currentContainer.RegisterType<ILocalDataService, LocalDataService>();
            this._currentContainer.RegisterType<INavigationService, NavigationService>();
            this._currentContainer.RegisterType<IReminderService, ReminderService>();
            this._currentContainer.RegisterType<IShareService, ShareService>();

            // Añade los ViewModels y asociales los Services que le correspondan (especificados en el constructor de cada ViewModel)
            this._currentContainer.RegisterType<IMainViewModel, MainViewModel>(new ContainerControlledLifetimeManager());
            this._currentContainer.RegisterType<IGroupDetailViewModel, GroupDetailViewModel>(new ContainerControlledLifetimeManager());
            this._currentContainer.RegisterType<IRecipeDetailViewModel, RecipeDetailViewModel>(new ContainerControlledLifetimeManager());
        }

        // Resuelve una dependencia
        public T Resolve<T>()
        {
            return _currentContainer.Resolve<T>();
        }
    }
}
