﻿using Microsoft.Phone.Controls;
using RecetarioWP7.Model;
using RecetarioWP7.ViewModel;

namespace RecetarioWP7.View
{
    public partial class RecipeDetailPage : PhoneApplicationPage
    {
        public RecipeDataItem RecipeItem
        {
            set { (DataContext as RecipeDetailViewModel).RecipeItem = value; }
        }

        public RecipeDetailPage()
        {
            InitializeComponent();
        }

        private void btnStartCooking_Click(object sender, System.EventArgs e)
        {
            (this.DataContext as RecipeDetailViewModel).StartCookingCommand.Execute(null);
        }

        private void btnShareShareTask_Click(object sender, System.EventArgs e)
        {
            (this.DataContext as RecipeDetailViewModel).ShareCommand.Execute(null);
        }

        private void btnPinToStart_Click(object sender, System.EventArgs e)
        {
            (this.DataContext as RecipeDetailViewModel).PinToStartCommand.Execute(null);
        }
    }
}