﻿using Microsoft.Phone.Controls;
using RecetarioWP7.Model;
using RecetarioWP7.ViewModel;

namespace RecetarioWP7.View
{
    public partial class GroupDetailPage : PhoneApplicationPage
    {
        public RecipeDataGroup RecipeGroup
        {
            set { (DataContext as GroupDetailViewModel).RecipeGroup = value; }
        }

        public GroupDetailPage()
        {
            InitializeComponent();
        }
    }
}