﻿using RecetarioWP7.Model;

namespace RecetarioWP7.ViewModel.Interfaces
{
    public interface IRecipeDetailViewModel
    {
        RecipeDataItem RecipeItem { get; set; }
    }
}
