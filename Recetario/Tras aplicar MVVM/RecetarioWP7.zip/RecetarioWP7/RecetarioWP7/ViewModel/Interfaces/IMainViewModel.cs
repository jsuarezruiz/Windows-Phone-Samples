﻿using RecetarioWP7.Model;
using System.Collections.ObjectModel;

namespace RecetarioWP7.ViewModel.Interfaces
{
    public interface IMainViewModel
    {
        ObservableCollection<RecipeDataGroup> Recipes { get; }
        RecipeDataGroup SelectedRecipeDataGroup { get; set; }
        void LoadRecipes();
        void SaveRecipesToIS();
        void UpdateTile();
    }
}
