﻿using RecetarioWP7.Model;

namespace RecetarioWP7.ViewModel.Interfaces
{
    public interface IGroupDetailViewModel
    {
        RecipeDataGroup RecipeGroup { get; set; }
    }
}
