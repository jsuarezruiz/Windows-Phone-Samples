﻿using RecetarioWP7.Model;
using RecetarioWP7.Services.Interfaces;
using RecetarioWP7.ViewModel.Base;
using RecetarioWP7.ViewModel.Interfaces;

namespace RecetarioWP7.ViewModel
{
    public class GroupDetailViewModel : BindableBase, IGroupDetailViewModel
    {
        #region Privates

        private RecipeDataGroup _recipeGroup;
        private RecipeDataItem _selectedRecipe;

        private INavigationService NavigationService;

        #endregion

        #region Properties

        public RecipeDataGroup RecipeGroup
        {
            get { return _recipeGroup; }
            set { _recipeGroup = value; }
        }

        public RecipeDataItem SelectedRecipe
        {
            get { return _selectedRecipe; }
            set
            {
                _selectedRecipe = value;
                this.NavigationService.NavigateToRecipeDetailPage(_selectedRecipe);
            }
        }

        #endregion

        #region Constructor

        public GroupDetailViewModel(INavigationService navigationService)
        {
            this.NavigationService = navigationService;
        }

        #endregion
    }
}
