﻿using System.Collections.Generic;

namespace RecetarioWP7.Services.Interfaces
{
    public interface ILocalDataService
    {
        IEnumerable<T> Load<T>(string file);
    }
}
