﻿using RecetarioWP7.Model;
using System.Collections.Generic;

namespace RecetarioWP7.Services.Interfaces
{
    public interface INavigationService
    {
        string GetNavigationSource();
        void NavigateToGroupDetailPage(RecipeDataGroup recipeDataGroup);
        void NavigateToRecipeDetailPage(RecipeDataItem recipeDataItem);
    }
}
