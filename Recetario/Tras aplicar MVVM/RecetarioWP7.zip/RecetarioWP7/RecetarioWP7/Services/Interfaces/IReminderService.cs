﻿using RecetarioWP7.Model;

namespace RecetarioWP7.Services.Interfaces
{
    public interface IReminderService
    {
        bool IsScheduled(string name);
        void SetReminder(RecipeDataItem item);
    }
}
