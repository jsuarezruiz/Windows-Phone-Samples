﻿
namespace RecetarioWP7.Services.Interfaces
{
    public interface IShareService
    {
        void Share(string title, string message);
    }
}
