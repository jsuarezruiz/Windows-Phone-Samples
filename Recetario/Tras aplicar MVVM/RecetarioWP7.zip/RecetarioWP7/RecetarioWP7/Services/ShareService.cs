﻿using Microsoft.Phone.Tasks;
using RecetarioWP7.Services.Interfaces;

namespace RecetarioWP7.Services
{
    public class ShareService : IShareService
    {
        public void Share(string title, string message)
        {
            EmailComposeTask emailComposeTask = new EmailComposeTask();
            emailComposeTask.To = "destinatario@correo.es";
            emailComposeTask.Subject = title;
            emailComposeTask.Body = message;

            emailComposeTask.Show();
        }
    }
}
