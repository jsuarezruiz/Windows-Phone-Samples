﻿using RecetarioWP7.Services.Interfaces;
using System.Windows;

namespace RecetarioWP7.Services
{
    public class DialogService : IDialogService
    {
        public void Show(string message)
        {
            MessageBox.Show(message);
        }

        public void Show(string message, string caption)
        {
            MessageBox.Show(message, caption, MessageBoxButton.OK);
        }
    }
}
