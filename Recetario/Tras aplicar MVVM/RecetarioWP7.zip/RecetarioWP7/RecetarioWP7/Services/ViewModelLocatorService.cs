﻿using RecetarioWP7.Ioc;
using RecetarioWP7.ViewModel;
using RecetarioWP7.ViewModel.Interfaces;

namespace RecetarioWP7.Services
{
    public class ViewModelLocatorService
    {
        // IoC container
        private IContainer _container;

        // Constructor
        public ViewModelLocatorService()
        {
            this._container = new Container();
        }

        // ViewModel principal para la colección de cartas
        public IMainViewModel MainViewModel
        {
            get
            {
                return this._container.Resolve<MainViewModel>();
            }
        }

        public IGroupDetailViewModel GroupDetailViewModel
        {
            get
            {
                return this._container.Resolve<GroupDetailViewModel>();
            }
        }

        public IRecipeDetailViewModel RecipeDetailViewModel
        {
            get
            {
                return this._container.Resolve<RecipeDetailViewModel>();
            }
        }
    }
}
