﻿using Microsoft.Phone.Controls;
using RecetarioWP7.Model;
using RecetarioWP7.Services.Interfaces;
using RecetarioWP7.View;
using System;

namespace RecetarioWP7.Services
{
    public class NavigationService : INavigationService
    {
        private RecipeDataItem _selectedRecipeDataItem;
        private RecipeDataGroup _selectedRecipeDataGroup;

        public string GetNavigationSource()
        {
            return (App.Current.RootVisual as PhoneApplicationFrame).Source.ToString();
        }

        public void NavigateToGroupDetailPage(RecipeDataGroup recipeDataGroup)
        {
            _selectedRecipeDataGroup = recipeDataGroup;
            (App.Current.RootVisual as PhoneApplicationFrame).Navigated += NavigateToGroupDetailPageNavigated;
            App.RootFrame.Navigate(new Uri("/View/GroupDetailPage.xaml", UriKind.Relative));
        }

        public void NavigateToRecipeDetailPage(RecipeDataItem recipeDataItem)
        {
            _selectedRecipeDataItem = recipeDataItem;
            (App.Current.RootVisual as PhoneApplicationFrame).Navigated += NavigateToRecipeDetailPageNavigated;
            App.RootFrame.Navigate(new Uri("/View/RecipeDetailPage.xaml", UriKind.Relative));
        }

        void NavigateToGroupDetailPageNavigated(object sender, System.Windows.Navigation.NavigationEventArgs e)
        {
            (App.Current.RootVisual as PhoneApplicationFrame).Navigated -= NavigateToGroupDetailPageNavigated;

            if (e.Content.GetType() == typeof(GroupDetailPage))
                (e.Content as GroupDetailPage).RecipeGroup = _selectedRecipeDataGroup;
        }

        void NavigateToRecipeDetailPageNavigated(object sender, System.Windows.Navigation.NavigationEventArgs e)
        {
            (App.Current.RootVisual as PhoneApplicationFrame).Navigated -= NavigateToRecipeDetailPageNavigated;

            if (e.Content.GetType() == typeof(RecipeDetailPage))
                (e.Content as RecipeDetailPage).RecipeItem = _selectedRecipeDataItem;
        }
    }
}
