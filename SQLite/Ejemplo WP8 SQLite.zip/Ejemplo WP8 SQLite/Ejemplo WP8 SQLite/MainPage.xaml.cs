﻿using Microsoft.Phone.Controls;
using System.Windows;

namespace Ejemplo_WP8_SQLite
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();

            InitDB();
        }

        private void InitDB()
        {
            using (var db = new SQLite.SQLiteConnection("books.sqlite"))
            {
                db.CreateTable<Book>();

                db.RunInTransaction(() =>
                {
                    db.Insert(new Book() { Title = "Windows Phone 7.5 Mango - Desarrollo Silverlight", Author = "Josué Yeray Julián" });
                    db.Insert(new Book() { Title = "Trabajando en equipo con Visual Studio ALM ", Author = "Bruno Capuano" });
                });

                int NumBooks1 = db.Table<Book>().Count();
                int NumBooks2 = db.ExecuteScalar<int>("SELECT COUNT(ID) FROM Book");

                MessageBox.Show(string.Format("Número de libros: {0}", NumBooks1));
            }
        }
    }

    public class Book
    {
        [SQLite.AutoIncrement, SQLite.PrimaryKey]
        public int ID { get; set; }

        [SQLite.MaxLength(256)]
        public string Title { get; set; }

        [SQLite.MaxLength(256)]
        public string Author { get; set; }
    }
}