
namespace CompanyHubClient.ViewModel.Base
{
    public interface INavigable
    {
        object NavigationContext { set; }
    }
}
