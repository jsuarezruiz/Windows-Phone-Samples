﻿using CompanyHubClient.ServiceReference;
using CompanyHubClient.Services.Interfaces;
using CompanyHubClient.ViewModel.Base;
using CompanyHubClient.ViewModel.Interfaces;
using System;
using System.Linq;
using System.Windows.Input;
using Windows.Phone.Management.Deployment;
using WPAppStudio.Entities.Base;

namespace CompanyHubClient.ViewModel
{
    public class AppDetailViewModel : BindableBase, IAppDetailViewModel, INavigable
    {
        private readonly IDialogService _dialogService;
        private CompanyApp _currentApp;

        /// <summary>
        /// CurrentApp property.
        /// </summary>		
        public CompanyApp CurrentApp
        {
            get { return _currentApp; }
            set
            {
                SetProperty(ref _currentApp, value);
            }
        }

        public AppDetailViewModel(IDialogService dialogService)
        {
            _dialogService = dialogService;
        }

        private ICommand _installCommand;

        /// <summary>
        /// Gets the InstallCommand command.
        /// </summary>
        public ICommand InstallCommand
        {
            get { return _installCommand = _installCommand ?? new DelegateCommand(InstallCommandDelegate); }
        }

        /// <summary>
        /// Delegate method for the InstallCommandDelegate command.
        /// </summary>
        public async void InstallCommandDelegate()
        {
            if (!string.IsNullOrEmpty(CurrentApp.XapPath))
            {
                var result = await InstallationManager.AddPackageAsync(CurrentApp.Title, new Uri(CurrentApp.XapPath));
                if (result.InstallState == Windows.Management.Deployment.PackageInstallState.Installed)
                    _dialogService.Show(CurrentApp.Title + " ha sido instalada.");
            }
            else
                _dialogService.Show("Ha ocurrido un error durante la instalación.");
        }

        private ICommand _launchCommand;

        /// <summary>
        /// Gets the LaunchCommand command.
        /// </summary>
        public ICommand LaunchCommand
        {
            get { return _launchCommand = _launchCommand ?? new DelegateCommand(LaunchCommandDelegate); }
        }

        /// <summary>
        /// Delegate method for the LaunchCommandDelegate command.
        /// </summary>
        public void LaunchCommandDelegate()
        {
            var devicePkgs = InstallationManager.FindPackagesForCurrentPublisher();
            var devicePkg = devicePkgs.FirstOrDefault(p => p.Id.ProductId.Contains(CurrentApp.ProductId.ToString().ToUpper()));

            if (devicePkg != null)
                devicePkg.Launch(string.Empty);
            else
                _dialogService.Show("No se puede lanzar la App.");
        }

        public object NavigationContext
        {
            set
            {
                if (!(value is CompanyApp)) { return; }

                CurrentApp = value as CompanyApp;
            }
        }
    }
}
