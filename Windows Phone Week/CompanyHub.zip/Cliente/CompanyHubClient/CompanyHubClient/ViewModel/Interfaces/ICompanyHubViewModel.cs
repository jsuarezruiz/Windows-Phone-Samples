﻿using CompanyHubClient.ServiceReference;
using System.Collections.ObjectModel;
using System.Threading.Tasks;

namespace CompanyHubClient.ViewModel.Interfaces
{
    public interface ICompanyHubViewModel
    {
        ObservableCollection<CompanyApp> NewApps { get; set; }
        ObservableCollection<CompanyApp> UpdateApps { get; set; }
        ObservableCollection<CompanyApp> InstalledApps { get; set; }
        CompanyApp SelectedApp { get; set; }
        void LoadFakeData();
    }
}
