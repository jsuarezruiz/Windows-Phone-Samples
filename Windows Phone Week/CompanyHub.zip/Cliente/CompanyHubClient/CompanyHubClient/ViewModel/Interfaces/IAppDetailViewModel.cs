﻿using CompanyHubClient.ServiceReference;

namespace CompanyHubClient.ViewModel.Interfaces
{
    public interface IAppDetailViewModel
    {
        CompanyApp CurrentApp { get; set; }
    }
}
