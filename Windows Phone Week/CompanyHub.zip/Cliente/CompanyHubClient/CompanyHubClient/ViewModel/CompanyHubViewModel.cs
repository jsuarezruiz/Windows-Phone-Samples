﻿using CompanyHubClient.Helper;
using CompanyHubClient.ServiceReference;
using CompanyHubClient.Services.Interfaces;
using CompanyHubClient.ViewModel.Interfaces;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using Windows.Phone.Management.Deployment;
using WPAppStudio.Entities.Base;

namespace CompanyHubClient.ViewModel
{
    public class CompanyHubViewModel : BindableBase, ICompanyHubViewModel
    {
        private IEnumerable<CompanyApp> _packages;
        private ObservableCollection<CompanyApp> _newApps;
        private ObservableCollection<CompanyApp> _updateApps;
        private ObservableCollection<CompanyApp> _installedApps;
        private CompanyApp _selectedApp;
        private INavigationService _navigationService;

        public ObservableCollection<CompanyApp> NewApps
        {
            get { return _newApps; }
            set { SetProperty(ref _newApps, value); }
        }

        public ObservableCollection<CompanyApp> UpdateApps
        {
            get { return _updateApps; }
            set { SetProperty(ref _updateApps, value); }
        }

        public ObservableCollection<CompanyApp> InstalledApps
        {
            get { return _installedApps; }
            set { SetProperty(ref _installedApps, value); }
        }

        public CompanyApp SelectedApp
        {
            get { return _selectedApp; }
            set
            {
                _selectedApp = value;
                if (value != null)
                    _navigationService.NavigateTo<IAppDetailViewModel>(_selectedApp);
            }
        }

        public CompanyHubViewModel(INavigationService navigationService)
        {
            _navigationService = navigationService;

            new Action(async () =>
            {
               await LoadDataAsync();
            }).Invoke();

            //LoadDataAsync();
        }

        // Obtiene el listado de Apps del servidor
        private async Task<List<CompanyApp>> GetAppListAsync()
        {
            var service = new CompanyHubServerClient();
            var tcs = new TaskCompletionSource<List<CompanyApp>>();

            EventHandler<GetCompanyAppsCompletedEventArgs> handler = null;
            handler = (s, ex) =>
            {
                service.GetCompanyAppsCompleted -= handler;

                if (ex.Error != null)
                    tcs.SetException(ex.Error);
                else
                    tcs.SetResult(ex.Result.ToList());
            };

            service.GetCompanyAppsCompleted += handler;
            service.GetCompanyAppsAsync();

            return await tcs.Task;
        }

        private async Task LoadDataAsync()
        {
            // Obtenemos el listado de Apps del servidor
            _packages = await GetAppListAsync();

            // Obtenemos el listado de Apps instaladas
            var installed = InstallationManager.FindPackagesForCurrentPublisher();

            foreach (var pkg in _packages)
            {
                var qry = installed.Where(p => p.Id.ProductId.ToLower().Contains(pkg.ProductId.ToString().ToLower()));

                if (qry.Any())
                {
                    var devicePkg = qry.First();
                    var devicePkgVersion =
                      CompanyAppHelper.Version(devicePkg.Id.Version);
                    pkg.Status = CompanyAppHelper.IsAnUpdate(
                      pkg.Version, devicePkgVersion) ?
                      Status.Update : Status.Installed;
                }
                else
                {
                    pkg.Status = Status.New;
                }
            }

            NewApps = new ObservableCollection<CompanyApp>(_packages.Where(p => p.Status == Status.New).ToList());
            UpdateApps = new ObservableCollection<CompanyApp>(_packages.Where(p => p.Status == Status.Update).ToList());
            InstalledApps = new ObservableCollection<CompanyApp>(_packages.Where(p => p.Status == Status.Installed).ToList());
        }

        public static IEnumerable<CompanyApp> CreateFakeData()
        {
            var data = new List<CompanyApp>();
            var pkgs = InstallationManager.FindPackagesForCurrentPublisher();

            foreach (var pkg in pkgs)
            {
                if (pkg.Id.Name != "CompanyHub")
                {
                    var compPkg = new CompanyApp
                    {
                        ProductId = new Guid(pkg.Id.ProductId),
                        Title = pkg.Id.Name,
                        Description = "Test Description",
                        Version = CompanyAppHelper.Version(pkg.Id.Version),
                        Icon = "/Assets/ApplicationIcon.png",
                        Status = Status.Installed
                    };

                    // Añadimos algunas actualizaciones
                    if (data.Count() > 2)
                        compPkg.Version = "2.0.0.0";

                    data.Add(compPkg);
                }
            }

            // Añadimos 10 Apps más de prueba
            for (int i = 0; i < 10; i++)
            {
                var compPkg = new CompanyApp
                {
                    ProductId = Guid.NewGuid(),
                    Title = "ExtraApp " + i,
                    Description = "Description",
                    Version = "1.0.0.0",
                    Icon = "/Assets/ApplicationIcon.png",
                    Status = Status.New
                };

                data.Add(compPkg);
            }

            return data;
        }

        public void LoadFakeData()
        {
            var apps = CreateFakeData();
            var companyApps = apps as CompanyApp[] ?? apps.ToArray();
            NewApps = new ObservableCollection<CompanyApp>(companyApps.Where(p => p.Status == Status.New).ToList());
            UpdateApps = new ObservableCollection<CompanyApp>(companyApps.Where(p => p.Status == Status.Update).ToList());
            InstalledApps = new ObservableCollection<CompanyApp>(companyApps.Where(p => p.Status == Status.Installed).ToList());
        }
    }
}
