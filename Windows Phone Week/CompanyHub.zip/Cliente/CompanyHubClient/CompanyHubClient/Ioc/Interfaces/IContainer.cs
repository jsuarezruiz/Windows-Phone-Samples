
namespace CompanyHubClient.Ioc.Interfaces
{
    public interface IContainer
    {
        T Resolve<T>();
    }
}
