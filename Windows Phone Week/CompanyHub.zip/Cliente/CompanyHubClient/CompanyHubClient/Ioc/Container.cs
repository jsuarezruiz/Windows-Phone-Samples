using CompanyHubClient.Ioc.Interfaces;
using CompanyHubClient.Services;
using CompanyHubClient.Services.Interfaces;
using CompanyHubClient.ViewModel;
using CompanyHubClient.ViewModel.Interfaces;
using Microsoft.Practices.Unity;

namespace WPAppStudio.Ioc
{
    //
    // Unity 2.1
    // http://msdn.microsoft.com/en-us/library/hh237493.aspx
    //
    // patterns & practices - Unity
    // http://unity.codeplex.com/
    //
    public class Container : IContainer
    {
        private readonly IUnityContainer _currentContainer;

        public Container()
        {
            _currentContainer = new UnityContainer();

            _currentContainer.RegisterType<INavigationService, NavigationService>();
            _currentContainer.RegisterType<IDialogService, DialogService>();

            _currentContainer.RegisterType<ICompanyHubViewModel, CompanyHubViewModel>();
            _currentContainer.RegisterType<IAppDetailViewModel, AppDetailViewModel>();
        }

        public T Resolve<T>()
        {
            return _currentContainer.Resolve<T>();
        }
    }
}
