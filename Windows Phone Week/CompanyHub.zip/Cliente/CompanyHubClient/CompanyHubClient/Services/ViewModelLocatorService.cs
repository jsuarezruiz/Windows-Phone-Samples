﻿using CompanyHubClient.Ioc.Interfaces;
using CompanyHubClient.ViewModel;
using CompanyHubClient.ViewModel.Interfaces;
using WPAppStudio.Ioc;

namespace CompanyHubClient.Services
{
    public class ViewModelLocatorService
    {
        // IoC container
        private readonly IContainer _container;

        /// <summary>
        /// Initializes a new instance of the <see cref="ViewModelLocatorService" /> class.
        /// </summary>
        public ViewModelLocatorService()
        {
            _container = new Container();
        }

        /// <summary>
        /// Gets the reference to a CompanyHubViewModel.
        /// </summary>
        public ICompanyHubViewModel CompanyHubViewModel
        {
            get { return _container.Resolve<CompanyHubViewModel>(); }
        }

        /// <summary>
        /// Gets the reference to a CompanyHubViewModel.
        /// </summary>
        public IAppDetailViewModel AppDetailViewModel
        {
            get { return _container.Resolve<AppDetailViewModel>(); }
        }
    }
}
