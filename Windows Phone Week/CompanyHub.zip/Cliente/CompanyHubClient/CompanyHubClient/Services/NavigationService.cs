﻿using CompanyHubClient.Services.Interfaces;
using CompanyHubClient.ViewModel.Base;
using CompanyHubClient.ViewModel.Interfaces;
using Microsoft.Phone.Controls;
using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Navigation;

namespace CompanyHubClient.Services
{
    public class NavigationService : INavigationService
    {
        private static readonly IDictionary<Type, string> ViewModelRouting = new Dictionary<Type, string>()
        {
            { typeof(ICompanyHubViewModel), "/View/CompanyHub.xaml" },
            { typeof(IAppDetailViewModel), "/View/AppDetail.xaml" }
        };

        private object _navigationContext;

        /// <summary>
        /// Generic method to navigate to a viewmodel
        /// </summary>
        /// <typeparam name="TDestinationViewModel">ViewModel type</typeparam>
        public void NavigateTo<TDestinationViewModel>()
        {
            var rootFrame = Application.Current.RootVisual as PhoneApplicationFrame;
            rootFrame.Navigate(new Uri(ViewModelRouting[typeof(TDestinationViewModel)], UriKind.Relative));
        }

        /// <summary>
        /// Generic method to navigate to a viewmodel passing a navigation context
        /// </summary>
        /// <typeparam name="TDestinationViewModel">ViewModel type</typeparam>
        /// <param name="navigationContext">Parameters passed to target ViewModel</param>
        public void NavigateTo<TDestinationViewModel>(object navigationContext)
        {
            this._navigationContext = navigationContext;

            var rootFrame = Application.Current.RootVisual as PhoneApplicationFrame;
            rootFrame.Navigated += new NavigatedEventHandler(Page_Navigated);
            rootFrame.Navigate(new Uri(ViewModelRouting[typeof(TDestinationViewModel)], UriKind.Relative));
        }

        /// <summary>
        /// Go back in the navigation stack.
        /// </summary>
        public void NavigateBack()
        {
            var rootFrame = Application.Current.RootVisual as PhoneApplicationFrame;
            if (rootFrame.CanGoBack)
            {
                rootFrame.GoBack();
            }
        }

        /// <summary>
        /// Go back in the navigation stack passing a navigation context.
        /// </summary>
        public void NavigateBack(object navigationContext)
        {
            this._navigationContext = navigationContext;

            var rootFrame = Application.Current.RootVisual as PhoneApplicationFrame;
            if (rootFrame.CanGoBack)
            {
                rootFrame.Navigated += new NavigatedEventHandler(Page_Navigated);
                rootFrame.GoBack();
            }
        }

        private void Page_Navigated(object sender, NavigationEventArgs e)
        {
            var rootFrame = Application.Current.RootVisual as PhoneApplicationFrame;
            rootFrame.Navigated -= Page_Navigated;

            // Pásale los parámetros a su vista-modelo
            ((e.Content as PhoneApplicationPage).DataContext as INavigable).NavigationContext = this._navigationContext;
        }

        /// <summary>
        /// Remove all items in navigation stack.
        /// </summary>
        public void ClearNavigationHistory()
        {
            var rootFrame = Application.Current.RootVisual as PhoneApplicationFrame;
            while (rootFrame.RemoveBackEntry() != null) ;
        }

        /// <summary>
        /// Get URI view corresponding to a ViewModel 
        /// </summary>
        public string GetUri(Type type)
        {
            return ViewModelRouting[type];
        }
    }
}
