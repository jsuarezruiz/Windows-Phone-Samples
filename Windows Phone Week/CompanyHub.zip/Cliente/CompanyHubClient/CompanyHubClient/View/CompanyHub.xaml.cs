﻿using Microsoft.Phone.Controls;

namespace CompanyHubClient
{
    public partial class CompanyHub : PhoneApplicationPage
    {
        // Constructor
        public CompanyHub()
        {
            InitializeComponent();
        }
    }
}