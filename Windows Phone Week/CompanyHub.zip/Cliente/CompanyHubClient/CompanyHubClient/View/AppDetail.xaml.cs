﻿using Microsoft.Phone.Controls;

namespace CompanyHubClient.View
{
    public partial class AppDetail : PhoneApplicationPage
    {
        public AppDetail()
        {
            InitializeComponent();
        }
    }
}