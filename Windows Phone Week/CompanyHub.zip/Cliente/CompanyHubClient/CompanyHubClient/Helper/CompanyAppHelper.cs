﻿using System;
using Windows.ApplicationModel;

namespace CompanyHubClient.Helper
{
    public static class CompanyAppHelper
    {
        public static string Version(PackageVersion version)
        {
            return String.Format("{0}.{1}.{2}.{3}",
                                version.Major,
                                version.Minor,
                                version.Build,
                                version.Revision);
        }

        public static bool IsAnUpdate(string newVersion, string oldVersion)
        {
            var newVer = System.Version.Parse(newVersion);
            var oldVer = System.Version.Parse(oldVersion);

            return newVer.CompareTo(oldVer) > 0;
        }
    }
}
