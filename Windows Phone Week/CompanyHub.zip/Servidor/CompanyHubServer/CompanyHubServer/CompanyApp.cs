﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace CompanyHubServer
{
    public enum Status
    {
        New,
        Update,
        Installed
    }

    [Serializable]
    [DataContract]
    public class CompanyApp
    {
        [DataMember]
        public Guid ProductId { get; set; }

        [DataMember]
        public string Title { get; set; }

        [DataMember]
        public string Description { get; set; }

        [DataMember]
        public string Author { get; set; }

        [DataMember]
        public string Icon { get; set; }

        [DataMember]
        public string XapPath { get; set; }

        [DataMember]
        public bool Downloading { get; set; }

        [DataMember]
        public uint Progress { get; set; }

        [DataMember]
        public string ProgressString { get; set; }

        [DataMember]
        public Status Status { get; set; }

        [DataMember]
        public string Version { get; set; }
    }
}