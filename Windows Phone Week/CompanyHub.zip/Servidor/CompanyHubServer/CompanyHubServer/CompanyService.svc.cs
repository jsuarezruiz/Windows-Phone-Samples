﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Serialization;

namespace CompanyHubServer
{
    public class CompanyService : ICompanyService
    {
        public List<CompanyApp> GetCompanyApps()
        {
            // just read the XML file, deserialize it and then send
            var appPath = System.Web.Hosting.HostingEnvironment.ApplicationPhysicalPath;

            CompanyApp[] packages;

            using (var sr = new StreamReader(appPath + "/CompanyApps.xml"))
            {
                var dcs = new XmlSerializer(typeof(CompanyApp[]), new[] { typeof(CompanyApp) });
                packages = dcs.Deserialize(sr.BaseStream) as CompanyApp[];
            }

            return packages.ToList();
        }
    }
}
