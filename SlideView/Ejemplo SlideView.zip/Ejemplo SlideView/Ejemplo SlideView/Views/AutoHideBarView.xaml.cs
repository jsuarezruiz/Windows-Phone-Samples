﻿using Ejemplo_SlideView.Views.Base;
using Windows.UI.ViewManagement;

namespace Ejemplo_SlideView.Views
{
    /// <summary>
    ///   SlideView
    /// </summary>
    public sealed partial class AutoHideBarView : PageBase
    {
        public AutoHideBarView()
        {
            this.InitializeComponent();

            StatusBar.GetForCurrentView().HideAsync();
        }

        private void SlideView_SelectionChanged(object sender, System.EventArgs e)
        {
            //Este evento se dispara cada vez que cambiemos el panel principal seleccionado.
        }
    }
}
