﻿using Ejemplo_SlideView.Views.Base;
using Windows.UI.Xaml.Navigation;

namespace Ejemplo_SlideView
{
    /// <summary>
    /// MainView
    /// </summary>
    public sealed partial class MainView : PageBase
    {
        public MainView()
        {
            this.InitializeComponent();

            this.NavigationCacheMode = NavigationCacheMode.Required;
        }
    }
}
