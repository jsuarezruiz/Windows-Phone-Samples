﻿using Ejemplo_SlideView.ViewModels.Base;
using System.Windows.Input;

namespace Ejemplo_SlideView.ViewModels
{
    public class MainViewModel : ViewModelBase
    {
        //Commands
        private ICommand _autoHideBarCommand;

        public override System.Threading.Tasks.Task OnNavigatedFrom(Windows.UI.Xaml.Navigation.NavigationEventArgs args)
        {
            return null;
        }

        public override System.Threading.Tasks.Task OnNavigatedTo(Windows.UI.Xaml.Navigation.NavigationEventArgs args)
        {
            return null;
        }

        public ICommand AutoHideBarCommand
        {
            get { return _autoHideBarCommand = _autoHideBarCommand ?? new DelegateCommand(AutoHideBarCommandDelegate); }
        }

        public void AutoHideBarCommandDelegate()
        {
            AppFrame.Navigate(typeof(Ejemplo_SlideView.Views.AutoHideBarView));
        }
    }
}
