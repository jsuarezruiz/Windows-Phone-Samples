﻿using Ejemplo_SlideView.ViewModels.Base;
using SlideView.Library;
using System.Collections.ObjectModel;

namespace Ejemplo_SlideView.ViewModels
{
    public class AutoHideBarViewModel : ViewModelBase
    {
        private ObservableCollection<string> _list;

        public AutoHideBarViewModel()
        {
            _list = new ObservableCollection<string>();
        }

        public ObservableCollection<string> List
        {
            get { return _list; }
            set { _list = value; }
        }

        public override System.Threading.Tasks.Task OnNavigatedFrom(Windows.UI.Xaml.Navigation.NavigationEventArgs args)
        {
            return null;
        }

        public override System.Threading.Tasks.Task OnNavigatedTo(Windows.UI.Xaml.Navigation.NavigationEventArgs args)
        {
            FillData();

            return null;
        }

        private void FillData()
        {
            for(int i = 0; i < 50; i++)
            {
                _list.Add(string.Format("List Item Number {0}", i + 1));
            }
        }
    }
}
